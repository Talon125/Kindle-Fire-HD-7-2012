if [ -e /data/usf- ]; then
	/system/xbin/busybox rm -rf /data/usf
	/system/bin/mv /data/usf- /data/usf
fi