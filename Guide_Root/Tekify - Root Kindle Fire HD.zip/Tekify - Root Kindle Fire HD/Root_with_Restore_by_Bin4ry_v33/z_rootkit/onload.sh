#!/system/bin/sh
/system/bin/chmod 777 /data
/system/bin/mkdir /data/usf
/system/bin/ln -s /dev /data/usf/dev
/system/bin/start usf-post-boot
/system/bin/sleep 2
/system/bin/ln -s /sys/kernel/uevent_helper /dev/usf1
/system/bin/start usf-post-boot
/system/bin/sleep 2
echo /data/local/tmp/getroot.sh > /sys/kernel/uevent_helper

