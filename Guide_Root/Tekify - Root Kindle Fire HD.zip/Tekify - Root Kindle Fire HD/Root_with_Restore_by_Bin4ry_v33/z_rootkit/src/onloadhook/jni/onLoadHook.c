#include <unistd.h>
#include <stdlib.h>
#define LOG_TAG "onLoadHook"
#include <jni.h>
#include <android/log.h>
#include <sys/wait.h>

#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__))
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__))
#define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__))
#define LOGE(...) ((void)__android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__))

JNIEXPORT jint JNICALL Java_com_sonyericsson_android_servicemenu_servicetests_JniMethod_getKeyCtrlVerify (
	JNIEnv* env, jobject thiz)
{
  return 0;
}

JNIEXPORT jint JNICALL Java_com_sonyericsson_android_servicemenu_servicetests_JniMethod_initDevice (
	JNIEnv* env, jobject thiz)
{
  return 0;
}

JNIEXPORT jint JNICALL Java_com_sonyericsson_android_servicemenu_servicetests_JniMethod_finalizeDevice (
	JNIEnv* env, jobject thiz)
{
  return 0;
}

JNIEXPORT jint JNICALL Java_com_sonyericsson_android_servicemenu_servicetests_JniMethod_setRGBColor (
	JNIEnv* env, jobject thiz)
{
  return 0;
}

JNIEXPORT jint JNICALL Java_com_sonyericsson_android_servicemenu_servicetests_JniMethod_getRootingStatus (
	JNIEnv* env, jobject thiz)
{
  return 0;
}

JNIEXPORT jint JNICALL Java_com_sonyericsson_android_servicemenu_servicetests_JniMethod_getSRMVerify (
	JNIEnv* env, jobject thiz)
{
  return 0;
}

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
  int status;
  pid_t pid;
  char *par[10];
  LOGI("JNI_OnLoad called");
  par[0] = "/system/bin/sh";
  par[1] = "/data/local/tmp/onload.sh";
  par[2] = (char*)0;
  pid = fork();
  LOGI("fork pid=%d", pid);
  if (!pid) {
    status = execve(par[0],par, environ);
    LOGI("execve status=%d", pid);
    exit(0);
  } else {
    waitpid(pid, &status, 0);
    LOGI("execve status=%d", pid);
  }
  return JNI_VERSION_1_6;
}

